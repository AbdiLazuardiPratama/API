<?php 

// $mahasiswa = [
// 	[
// 			"nama" 	=> "Goku",
// 			"nrp"	=> "1730666",
// 			"email"	=> "kakarot21@unpas.ac.id"	
// 	],
// 	[
// 			"nama" 	=> "Gohan",
// 			"nrp"	=> "1730667",
// 			"email"	=> "gohan21@unpas.ac.id"	
// 	]

// ];
$dbh = new PDO('mysql:host=localhost;dbname=akademik','root','');
$db = $dbh->prepare('SELECT * FROM mahasiswa');
$db->execute();
$mahasiswa = $db->fetchAll(PDO::FETCH_ASSOC);

$data = json_encode($mahasiswa);
echo $data;


?>