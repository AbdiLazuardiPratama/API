$.getJSON('data/clucNBell.json', function (data) {
	let menu = data.menu;
	$.each(menu, function(i, data) {
		$('#daftar-menu').append('<div class="col-md-4"><divclass="card mb-3 mr-5" style="width: 10rem;"><img src="img/' + data.gambar + ' class="card-img-top"><div class="card-body"><h5 class="card-title">' + data.nama + '</h5><p class="card-text"></p><h5 class="card-title">' + data.harga + '</h5><a class="btn btn-primary">Go somewhere</a></div></div></div> ')});
});